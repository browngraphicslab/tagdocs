var Config = {
    debug: false,
    forceIERenderPath: true,
    outputMultiLODTiles: true,
    scanConvertSize: 40,
	polyInflate: 0.05
};
