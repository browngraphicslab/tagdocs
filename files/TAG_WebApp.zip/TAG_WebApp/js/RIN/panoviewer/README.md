


Read-Write-World rendering components.

This is an initial version of common low level rendering api and components.

Setup and Build (win32):

Install java (used by our minifier).
http://www.oracle.com/technetwork/java/javase/downloads/java-se-jdk-7-download-432154.html

Unzip data directory to examples\psViewer\data for webgl & flash testing.

Point IIS virtual directory to rwwviewer root.

From the rwwviewer root, run tools\build.bat to concatenate and minify the math & graphics library.
