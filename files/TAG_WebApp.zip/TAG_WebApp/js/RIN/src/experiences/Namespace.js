(function() {
    "use strict";
    var rin = window.rin || {};
    window.rin = rin;

    // RIN core looks for the presence of this object when
    // deciding to dynamically load the experiences JS
    rin.experiences = rin.experiences || {};

}());