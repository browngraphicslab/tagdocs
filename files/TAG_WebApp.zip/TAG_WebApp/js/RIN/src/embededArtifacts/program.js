// JavaScript
rin.embeddedArtifactTests.runTests();