/// <reference path="rintypes.d.ts" />
module rin.Ext.Trajectory {
    function newTrajectoryBuilder(e: Experience): TrajectoryBuilder;
}
