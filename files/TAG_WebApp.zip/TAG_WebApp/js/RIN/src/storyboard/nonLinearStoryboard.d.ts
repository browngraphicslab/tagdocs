/// <reference path="rintypes.d.ts" />
module rin.Ext.NonLinearStoryboard {
    function buildStoryboard(sb: StoryboardHelper): IStoryboard;
}
