﻿function foo(id) {
    document.getElementById(id).innerHTML = "theme1";
}

